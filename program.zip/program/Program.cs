﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Timers;

namespace UltimateQuiz
{
    class Program
    {
        static void Main(string[] args)
        {
            GameObject game = new GameObject();
            game.Engine();
        }
    }
    public class GameObject
    {
        private bool gameActive = true;
        private bool checkFileOk = false;
        private int quantityQuestions;
        private string endAnswer;
        private string difficultyLevel;
        private const string DIFFICULTY_LEVEL_ORGINAL = "średni";
        private int timeToAnswer;
        private const int TIME_EASY = 120;
        private const int TIME_NORMAL = 90;
        private const int TIME_HARD = 60;
        private const bool NEW_QUESTION_USED = false;
        private int menuOption;
        private string pathPlayers = "gracze.csv";
        private string pathQuestions = "pytania.csv";
        private int randomQuestion;
        Random draw = new Random();
        Question question = new Question();
        List<Question> questionsList = new List<Question>();
        private int newQuestionId;
        private string newQuestionText;
        private string newQuestionAnswerA;
        private string newQuestionAnswerB;
        private string newQuestionAnswerC;
        private string newQuestionAnswerD;
        private string newQuestionAnswerOK;
        private bool success;
        private int points;
        private int timeLeft;
        private string questionsFileFirstLine = "IdPytanie;Pytanie;OdpA;OdpB;OdpC;OdpD;OdpOK;Użyte";
        private int round;
        private bool warningWas = false;
        Timer timerToExit;
        List<Player> playerList = new List<Player>();
        bool checkPlayerFile;
        private void ExitTimer(Object source, ElapsedEventArgs e) 
        {
            Environment.Exit(0);
        }
        public void TestDev()
        {
            /*
            var uri = "https://www.google.com";
            var psi = new System.Diagnostics.ProcessStartInfo();
            psi.UseShellExecute = true;
            psi.FileName = uri;
            System.Diagnostics.Process.Start(psi);
        */
        }
        public void Engine()
        {
            Init();
            if (checkFileOk == true)
            {
                Game();
            }
        }
        private void Init() 
        {
            CheckFile();
            if (checkFileOk == true)
            {
                HowManyQuestions();
                difficultyLevel = DIFFICULTY_LEVEL_ORGINAL;
                SetDifficultyTime();
            }
        }
        private void Game()
        {
            while (gameActive == true)
            {
                Menu();
                switch (menuOption)
                {
                    case 1:
                        Quiz();
                        break;
                    case 2:
                        Create();
                        break;
                    case 3:
                        Options();
                        break;
                    case 4:
                        Info();
                        break;
                    case 5:
                        Quit();
                        break;
                }
            }
        }
        private void Menu()
        {
            while (true)
            {
                Console.Clear();
                CenterText("ULTIMATE QUIZ", true);
                CenterText("1.Nowa Gra", false);
                CenterText("2.Stwórz Pytanie", false);
                CenterText("3.Opcje", false);
                CenterText("4.Info", false);
                CenterText("5.Zamknij", false);
                Console.Write("\n\nWybierz numer opcji którą chczesz uruchomić: ");
                if (int.TryParse(Console.ReadLine(), out menuOption) == true)
                {
                    if (menuOption > 0 && menuOption < 6)
                    {
                        return;
                    }
                    else 
                    {
                        Console.Clear();
                        Console.Write("Podana liczba muszi należeć do przedziału między 1 a 5\nNaciśnij przycisk by wrócić do menu\n");
                        Console.ReadKey();
                    }
                }
                else 
                {
                    Console.Clear();
                    Console.Write("Podana wartość musi być liczbą całkowitą\nNaciśnij przycisk by wrócić do menu\n");
                    Console.ReadKey();
                }
            }
        }
        private void Quiz()
        {
            Console.Clear();
            CheckRestQuestion();
            round = 1;
            while(round < 21) 
            {
                Console.Clear();
                DrawQuestion();
                ShowAnswerQuestion();
                if(success == true) 
                {
                    Points();
                    round++;
                }
                CheckRestQuestion();
                if(success == false) 
                {
                    break;
                }
            }
            EndGame();
        }
        private void Create()
        {
            newQuestionId = ++quantityQuestions;
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Podaj treść pytania (min. 1 znak i maksimum 140):");
                newQuestionText = Console.ReadLine();
                if (newQuestionText.Length > 0 && newQuestionText.Length <= 140) 
                {
                    break;
                }
                else 
                {
                    Console.Clear();
                    Console.WriteLine("Pytanie musi byc dłuższe niż 5 znaków oraz krótsze niż 140 znaków.");
                    Console.WriteLine("Po naciśnieciu dowolnego przycisku będziesz mógł wprowadzić treść pytania jeszcze raz.");
                    Console.ReadKey();
                }
            }
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Podaj treść odpowiedzi A (min. 1 znak):");
                newQuestionAnswerA = Console.ReadLine();
                if (newQuestionAnswerA.Length > 0)
                {
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Odpowiedź A musi mieć co najmniej 1 znak.");
                    Console.WriteLine("Po naciśnieciu dowolnego przycisku będziesz mógł wprowadzić treść pytania jeszcze raz.");
                    Console.ReadKey();
                }
            }
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Podaj treść odpowiedzi B (min. 1 znak):");
                newQuestionAnswerB = Console.ReadLine();
                if (newQuestionAnswerB.Length > 0)
                {
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Odpowiedź B musi mieć co najmnniej 1 znak.");
                    Console.WriteLine("Po naciśnieciu dowolnego przycisku będziesz mógł wprowadzić treść pytania jeszcze raz.");
                    Console.ReadKey();
                }
            }
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Podaj treść odpowiedzi C (min. 1 znak):");
                newQuestionAnswerC = Console.ReadLine();
                if (newQuestionAnswerC.Length > 0)
                {
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Odpowiedź C musi mieć co najmniej 1 znak.");
                    Console.WriteLine("Po naciśnieciu dowolnego przycisku będziesz mógł wprowadzić treść pytania jeszcze raz.");
                    Console.ReadKey();
                }
            }
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Podaj treść odpowiedzi D (min. 1 znak):");
                newQuestionAnswerD = Console.ReadLine();
                if (newQuestionAnswerD.Length > 0)
                {
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Odpowiedź D musi mieć co najmniej 1 znak.");
                    Console.WriteLine("Po naciśnieciu dowolnego przycisku będziesz mógł wprowadzić treść pytania jeszcze raz.");
                    Console.ReadKey();
                }
            }
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Podaj która odpowiedź jest prawidłowa (A/B/C/D):");
                newQuestionAnswerOK = Console.ReadLine();
                newQuestionAnswerOK = newQuestionAnswerOK.ToUpper();
                if (newQuestionAnswerOK.Length > 0 && newQuestionAnswerOK.Length < 2 && (newQuestionAnswerOK == "A" || newQuestionAnswerOK == "B" || newQuestionAnswerOK == "C" || newQuestionAnswerOK == "D"))
                {
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Prawidłową odpowiedź musisz podać w postaci jedne znaku");
                    Console.WriteLine("Po naciśnieciu dowolnego przycisku będziesz mógł wprowadzić treść pytania jeszcze raz.");
                    Console.ReadKey();
                }
            }
            SaveQuestion();
        }
        private void Options()
        {
            while (true)
            {
                SetDifficultyTime();
                Console.Clear();
                Console.WriteLine("Poziom trudności: {0}", difficultyLevel);
                Console.WriteLine("Czas na odpowiedź: {0} sekund", timeToAnswer);
                Console.WriteLine("0 - powrót do menu");
                Console.WriteLine("1 - zmiana poziomu trudności");
                Console.Write("Podaj numer opcji którą chczes wybrać: ");
                if (int.TryParse(Console.ReadLine(), out int answerOption) == true && answerOption >= 0 && answerOption < 2)
                {
                    switch (answerOption)
                    {
                        case 1:
                            ChangeOption();
                            break;
                        case 0:
                            break;
                    }
                    if (answerOption == 0)
                    {
                        break;
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Podana wartość nie jest liczbą całkowitą lub nie jest 0 lub 1");
                    Console.WriteLine("Nacisnij klawisz by wprowadzić dane ponownie");
                    Console.ReadKey();
                }
            }
        }
        private void Info()
        {
            Console.Clear();
            CenterText("Autor:Jakub Kittel", true);
            CenterText($"Ilość pytań: {quantityQuestions}", false);
            CenterText("RANKING", false);
            CenterText("Nazwa Gracza _____ Wynik Gracza", false);
            playerList.Sort((p, q) => p.playerScore.CompareTo(q.playerScore));
            playerList.Reverse();
            foreach (Player theBest in playerList) 
            {
                CenterText(theBest.playerName + " _____ " + theBest.playerScore, false);
            }
            Console.WriteLine("\nNaciśnij klawisz by wrócić do menu");
            Console.ReadKey();
        }
        private void Quit()
        {
            while (true)
            {
                Console.Clear();
                Console.Write("Czy na pewno chczesz opuścić program?(tak/nie) ");
                endAnswer = Console.ReadLine();
                endAnswer = endAnswer.ToLower();
                if (endAnswer == "tak")
                {
                    gameActive = false;
                    break;
                }
                else if (endAnswer == "nie")
                {
                    break;
                }
                else
                {
                    Console.Write("\nWprowadzono nie zrozumiałe dane.\nSpróbuj jeszcze raz.\n");
                    Console.ReadKey();
                }
            }
        }
        private void CheckFile()
        {
            if (File.Exists(pathQuestions) == true)
            {
                using (StreamReader questionsReader = new StreamReader(pathQuestions))
                {
                    if (questionsReader != null)
                    {
                        checkFileOk = true;
                    }
                }
            }
            if(File.Exists(pathPlayers) == true) 
            {
                checkPlayerFile = true;
                using (StreamReader playersReader = new StreamReader(pathPlayers)) 
                {
                    if(playersReader != null) 
                    {
                        int playerLineNumber = 0;
                        string[] parts;
                        while (!playersReader.EndOfStream) 
                        {
                            string playerLine = playersReader.ReadLine();
                            if(playerLineNumber > 0) 
                            {
                                parts = playerLine.Split(";");
                                if(int.TryParse(parts[1],out int score) && score >= 0) 
                                {
                                    playerList.Add(new Player
                                    {
                                        playerName = parts[0],
                                        playerScore = score
                                    });
                                }
                                else 
                                {
                                    Console.WriteLine("Błąd! Wynik nie jest podany w pliku w formie liczby całkowitej!");
                                    Console.WriteLine("Nacisćni klawisz aby kontynuować!");
                                    Console.ReadKey();
                                }
                            }
                            else 
                            {
                                playerLineNumber++;
                            }
                        }
                    }
                }
            }
            else 
            {
                File.Create(pathPlayers);
                checkPlayerFile = true;
            }
        }
        private void DrawQuestion()
        {
            QuestionToList();
            int[] questionIdRandom = new int[quantityQuestions];
            int j = 0;
            foreach (Question questionArray in questionsList) 
            {
                if(questionArray.used == false) 
                {
                    questionIdRandom[j] = questionArray.questionId;
                }
                else 
                {
                    questionIdRandom[j] = 0;
                }
                j++;
            }
            randomQuestion = draw.Next(0, quantityQuestions-1);
            while(questionIdRandom[randomQuestion] == 0) 
            {
                if (randomQuestion < (quantityQuestions - 1))
                {
                    randomQuestion++;
                }
                else 
                {
                    randomQuestion = 0;
                }
            }
            int idRandom;
            idRandom = questionIdRandom[randomQuestion];
            foreach (Question questionFind in questionsList) 
            {
                if(idRandom == questionFind.questionId) 
                {
                    question.questionText = questionFind.questionText;
                    question.answerA = questionFind.answerA;
                    question.answerB = questionFind.answerB;
                    question.answerC = questionFind.answerC;
                    question.answerD = questionFind.answerD;
                    question.answerOK = questionFind.answerOK;
                    questionFind.used = true;
                    break;
                }
            }
            SaveQuestions();
            questionsList.Clear();
        }
        private void HowManyQuestions()
        {
            string questionLine;
            using (StreamReader questionsReader = new StreamReader(pathQuestions))
            {
                if (questionsReader != null)
                {
                    int questionNumber = 0;

                    while (!questionsReader.EndOfStream)
                    {
                        questionLine = questionsReader.ReadLine();
                        questionNumber++;
                    }
                    questionNumber--;
                    quantityQuestions = questionNumber;
                }
            }
        }
        private void FreeSaveQuestions() 
        {
            QuestionToList();
            foreach (Question questionf in questionsList) 
            {
                questionf.used = false;
            }
            SaveQuestions();
            questionsList.Clear();
        }
        private void ChangeOption() 
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Poziom trudności:");
                Console.WriteLine("1 - łatwy");
                Console.WriteLine("2 - średni");
                Console.WriteLine("3 - trudny");
                Console.WriteLine("4 - domyślny");
                Console.Write("Podaj numer nowego poziomu trudności:");
                if(int.TryParse(Console.ReadLine(),out int answerChangeOption) && answerChangeOption < 5 && answerChangeOption > 0) 
                {
                    switch (answerChangeOption) 
                    {
                        case 1:
                            difficultyLevel = "łatwy";
                            break;
                        case 2:
                            difficultyLevel = "średni";
                            break;
                        case 3:
                            difficultyLevel = "trudny";
                            break;
                        case 4:
                            difficultyLevel = DIFFICULTY_LEVEL_ORGINAL;
                            break;
                    }
                    break;
                }
            }
        }
        private void SetDifficultyTime() 
        {
            if (difficultyLevel == "średni")
            {
                timeToAnswer = TIME_NORMAL;
            }
            else if (difficultyLevel == "łatwy")
            {
                timeToAnswer = TIME_EASY;
            }
            else if (difficultyLevel == "trudny")
            {
                timeToAnswer = TIME_HARD;
            }
            else { }
        }
        private void QuestionToList() 
        {
            using (StreamReader questionsReader = new StreamReader(pathQuestions))
            {
                if (questionsReader != null)
                {
                    int questionLineNumber = 0;
                    string[] parts;
                    while (!questionsReader.EndOfStream)
                    {
                        string questionLine = questionsReader.ReadLine();
                        if (questionLineNumber > 0)
                        {
                            parts = questionLine.Split(";");
                            if (int.TryParse(parts[0], out int id) == true)
                            {
                                if (id > 0)
                                {
                                    if (int.TryParse(parts[7],out int iUsedLine) == true && iUsedLine >= 0 && iUsedLine < 2)
                                    {
                                        bool usedLine = Convert.ToBoolean(iUsedLine);
                                        questionsList.Add(new Question()
                                        {
                                            questionId = id,
                                            questionText = parts[1],
                                            answerA = parts[2],
                                            answerB = parts[3],
                                            answerC = parts[4],
                                            answerD = parts[5],
                                            answerOK = parts[6],
                                            used = usedLine,
                                        });
                                    }
                                    else
                                    {
                                        Console.WriteLine("Program wykrył błąd w typie danych prawdy.");
                                        Console.WriteLine("Po naciśnięciu dowolnego przycisku program zostanie zamknięty.");
                                        Console.ReadKey();
                                        Environment.Exit(0);
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Id pytania nie może być mniejsze od 1");
                                    Console.WriteLine("Po naciśnięciu dowolnego przycisku program zostanie zamknięty.");
                                    Console.ReadKey();
                                    Environment.Exit(0);
                                }
                            }
                            else
                            {
                                Console.WriteLine("Program wykrył błąd w typie danych id.");
                                Console.WriteLine("Po naciśnięciu dowolnego przycisku program zostanie zamknięty.");
                                Console.ReadKey();
                                Environment.Exit(0);
                            }
                        }
                        questionLineNumber++;
                    }
                }
                else 
                {
                    Console.Clear();
                    Console.WriteLine("Plik z pytaniami jest pusty");
                    Console.WriteLine("Po naciśnięciu dowolnego przycisku program zostanie zamknięty.");
                    Console.ReadKey();
                    Environment.Exit(0);
                }
            }
        }
        private void SaveQuestions() 
        {
            using(StreamWriter writerQuestion = new StreamWriter(pathQuestions, false)) 
            {
                writerQuestion.WriteLine(questionsFileFirstLine);
                foreach (Question questionSave in questionsList) 
                {
                    writerQuestion.WriteLine(questionSave.questionId + ";" + questionSave.questionText + ";" + questionSave.answerA + ";" + questionSave.answerB + ";" + questionSave.answerC + ";" + questionSave.answerD + ";" + questionSave.answerOK + ";" + Convert.ToInt32(questionSave.used));
                }
            }
        }
        private void ShowAnswerQuestion() 
        {
            string userAnswer;
            timerToExit = new Timer();
            Timer timerSecond = new Timer();
            Timer timerAnswerTime = new Timer();
            timeLeft = timeToAnswer;
            timerSecond.Interval = 1000;
            timerSecond.Elapsed += SecondMinus;
            timerSecond.Start();
            timerAnswerTime.Interval = timeToAnswer * 1000;
            timerAnswerTime.Elapsed += Warning;
            timerAnswerTime.Start();
            while (true)
            {
                Console.WriteLine(question.questionText);
                Console.WriteLine("A - {0}", question.answerA);
                Console.WriteLine("B - {0}", question.answerB);
                Console.WriteLine("C - {0}", question.answerC);
                Console.WriteLine("D - {0}", question.answerD);
                Console.Write("Podaj swoją odpowieź (w postaci A/B/C/D): ");
                userAnswer = Console.ReadLine();
                userAnswer = userAnswer.ToUpper();
                if (userAnswer == "A" || userAnswer == "B" || userAnswer == "C" || userAnswer == "D") 
                {
                    timerSecond.Stop();
                    timerSecond.Dispose();
                    timerAnswerTime.Stop();
                    timerAnswerTime.Dispose();
                    if(warningWas == true) 
                    {
                        timerToExit.Stop();
                        timerToExit.Dispose();
                    }
                    break;
                }
            }
            if(userAnswer == question.answerOK && timeLeft > 0) 
            {
                success = true;
            }
            else 
            {
                success = false;
            }
        }
        private void Warning(object sender, ElapsedEventArgs e)
        {
            warningWas = true;
            Console.WriteLine("\nKoniec czasu!");
            Console.WriteLine("Udziel odpowiedzi inaczej za 10 sekund program zostanie wyłączony");
            timerToExit.Interval = 10000;
            timerToExit.Elapsed += ExitTimer;
            timerToExit.Start();
        }
        private void SecondMinus(object sender, ElapsedEventArgs e)
        {
            timeLeft--;
        }
        private void Points() 
        {
            if(difficultyLevel == "łatwy") 
            {
                points = points + (timeLeft * 50);
            }
            else if(difficultyLevel == "średni")
            {
                points = points + (timeLeft * 100);
            }
            else 
            {
                points = points + (timeLeft * 200);
            }
        }
        private void CheckRestQuestion() 
        {
            bool isFreeQuestion = false;
            QuestionToList();
            foreach(Question questionCheck in questionsList) 
            {
                if(questionCheck.used == false) 
                {
                    isFreeQuestion = true;
                    break;
                }
            }
            questionsList.Clear();
            if (isFreeQuestion == false) 
            {
                FreeSaveQuestions();
            }
        }
        public void EndGame() 
        {
            string newPlayerName;
            if (success == true) 
            {
                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Zwycięstwo");
                    Console.WriteLine("Zdobyte punkty: {0}", points);
                    if (checkPlayerFile == true)
                    {
                        Console.Write("Podaj nazwe gracza: ");
                        newPlayerName = Console.ReadLine();
                        if (float.TryParse(newPlayerName, out float result) == false)
                        {
                            if (newPlayerName.Length > 0 && newPlayerName.Length <= 32)
                            {
                                playerList.Add(new Player
                                {
                                    playerName = newPlayerName,
                                    playerScore = points,
                                });
                                playerList.Sort((p, q) => p.playerScore.CompareTo(q.playerScore));
                                playerList.Reverse();
                                if (playerList.Count > 10)
                                {
                                    playerList.RemoveAt(10);
                                }
                                try
                                {
                                    using (StreamWriter savePlayers = new StreamWriter(pathPlayers))
                                    {
                                        savePlayers.WriteLine("Imie gracza; Wynik gracza");
                                        foreach (Player savePlayer in playerList)
                                        {
                                            savePlayers.WriteLine(savePlayer.playerName + ";" + savePlayer.playerScore);
                                        }
                                    }
                                }
                                catch (Exception e)
                                {
                                    Console.WriteLine("Błąd! " + e.Message);
                                }
                                Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                                Console.ReadKey();
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Nazwa gracza nie może mieć mniej od 1 znaku oraz może mieć maksimum 32 znaki");
                                Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                                Console.ReadKey();
                            }
                        }
                        else
                        {
                            Console.WriteLine("Nazwa gracza nie może być liczbą");
                            Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                            Console.ReadKey();
                        }
                    }
                }
            }
            else 
            {
                while (true)
                {
                    Console.Clear();
                    Console.WriteLine("Porażka");
                    Console.WriteLine("Zdobyte punkty: {0}", points);
                    if (round > 1)
                    {
                        Console.WriteLine("Udało ci się przejść {0} rund", round);
                    }
                    else
                    {
                        Console.WriteLine("Nie udało ci się przejść ani jednej rundy");
                    }
                    if (checkPlayerFile == true)
                    {
                        Console.Write("Podaj nazwe gracza: ");
                        newPlayerName = Console.ReadLine();
                        if (float.TryParse(newPlayerName, out float result) == false)
                        {
                            if (newPlayerName.Length > 0 && newPlayerName.Length <= 32)
                            {
                                playerList.Add(new Player
                                {
                                    playerName = newPlayerName,
                                    playerScore = points,
                                });
                                playerList.Sort((p, q) => p.playerScore.CompareTo(q.playerScore));
                                playerList.Reverse();
                                if (playerList.Count > 10)
                                {
                                    playerList.RemoveAt(10);
                                }
                                try
                                {
                                    using (StreamWriter savePlayers = new StreamWriter(pathPlayers))
                                    {
                                        savePlayers.WriteLine("Imie gracza; Wynik gracza");
                                        foreach (Player savePlayer in playerList)
                                        {
                                            savePlayers.WriteLine(savePlayer.playerName + ";" + savePlayer.playerScore);
                                        }
                                    }
                                }
                                catch(Exception e) 
                                {
                                    Console.WriteLine("Błąd! " + e.Message);
                                }
                                Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                                Console.ReadKey();
                                break;
                            }
                            else
                            {
                                Console.WriteLine("Nazwa gracza nie może mieć mniej od 1 znaku oraz może mieć maksimum 32 znaki");
                                Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                                Console.ReadKey();
                            }
                        }
                        else
                        {
                            Console.WriteLine("Nazwa gracza nie może być liczbą");
                            Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                            Console.ReadKey();
                        }
                    }
                    Console.WriteLine("Naciśnij dowolny przycisk, by kontynuować");
                    Console.ReadKey();
                }
            }
        }
        private void SaveQuestion() 
        {
            using (StreamWriter writerQuestion = new StreamWriter(pathQuestions, true))
            {
                writerQuestion.WriteLine(newQuestionId+";"+newQuestionText+";"+newQuestionAnswerA+";"+newQuestionAnswerB+";"+newQuestionAnswerC+";"+newQuestionAnswerD+";"+newQuestionAnswerOK+";"+Convert.ToInt32(NEW_QUESTION_USED));
            }
        }
        private void CenterText(string text, bool firstLine) 
        {
            if (firstLine == false)
            {
                Console.Write("\n");
            }
            for (int i = 0; i < (Console.WindowWidth - text.Length) / 2; i++)
            {
                Console.Write(" ");
            }
            Console.Write(text);
        }
    }
    public class Question
    {
        public int questionId;
        public string questionText;
        public string answerA;
        public string answerB;
        public string answerC;
        public string answerD;
        public string answerOK;
        public bool used;
    }
    public class Player 
    {
        public string playerName;
        public int playerScore;
    }
}

